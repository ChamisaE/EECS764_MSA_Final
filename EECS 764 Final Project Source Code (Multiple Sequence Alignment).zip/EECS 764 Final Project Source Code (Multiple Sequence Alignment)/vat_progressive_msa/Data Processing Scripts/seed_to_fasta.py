from Bio import AlignIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio import SeqIO

# input seed file
input_file = "PF00010.alignment.seed"
output_file = "PF00010_seed.fasta"

alignment = AlignIO.read(input_file, "stockholm")
records = []

for record in alignment:
    ungapped_seq = Seq(str(record.seq).replace("-", ""))  # remove gaps
    records.append(SeqRecord(ungapped_seq, id=record.id, description=""))

SeqIO.write(records, output_file, "fasta")
print(f"Ungapped sequences written to {output_file}")
