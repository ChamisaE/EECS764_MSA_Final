#!/usr/bin/env python3
from Bio import AlignIO
from Bio.Align import MultipleSeqAlignment
import os
import subprocess
import sys
import time

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.abspath(os.path.join(CURRENT_DIR, ".."))
FASTA_FILE = os.path.join(PARENT_DIR, "PF00029_seed.fasta")
GUIDETREE_SCRIPT = os.path.join(PARENT_DIR, "VAT_guidetree5.py")
GIBBS_SCRIPT = os.path.join(CURRENT_DIR, "gibbs_test.py")
CLUSTALO_OUT = os.path.join(CURRENT_DIR, "clustalo_default.fasta")
VAT_MSA = os.path.join(CURRENT_DIR, "aligned_sequences.fasta")
running_tools = True

if running_tools == True:
    print("\n=== Running VAT-based guide-tree program ===")
    v0 = time.time()
    subprocess.run(
        ["python3", GUIDETREE_SCRIPT],        
        check=True,
        cwd=PARENT_DIR
    )
    v1 = time.time()
    print(f"VAT MSA tool completed in {v1 - v0:.2f} seconds")

    if not os.path.exists(VAT_MSA):
        print("ERROR: VAT MSA did not get created.")
        sys.exit(1)

    print("\n=== Running ClustalO Default Alignment ===")
    c0 = time.time()
    subprocess.run([
        "clustalo",
        "-i", FASTA_FILE,
        "-o", CLUSTALO_OUT,
        "--force",
        "--outfmt", "fasta"
    ], check=True)
    c1 = time.time()
    print(f"ClustalO tool completed in {c1 - c0:.2f} seconds")

    print("\n=== Gibbs Sampling Local Alignment ===")
    g0 = time.time()
    subprocess.run(
        ["python3", GIBBS_SCRIPT, FASTA_FILE, "10"],
        check=True,
    )
    g1 = time.time()
    print(f"Gibbs Sampling tool completed in {g1 - g0:.2f} seconds")

def evaluate_alignment(pfam_file, msa_file, label, tool):
    subprocess.run([
        "python3", "normalize_alignments.py",
        pfam_file, msa_file
    ], check=True)

    norm_ref = "ref_normalized.fasta"
    norm_pred = "pred_normalized.fasta"

    subprocess.run([
        "java", "-jar",
        "FastSP/FastSP.jar",
        "-r", norm_ref,
        "-e", norm_pred,
        "-o", f"{tool}_scores.txt"
    ], check=True)

# ============================================================
# Run comparisons
# ============================================================
pfam_file = "PF00029.alignment.seed"
vat_msa = "aligned_sequences.fasta"
clustalo_msa = "clustalo_default.fasta"
gibbs_msa = "gibbs_aligned.fasta"

evaluate_alignment(pfam_file, vat_msa, "Your VAT-guided MSA", "VAT")
evaluate_alignment(pfam_file, clustalo_msa, "ClustalO Default MSA", "ClustalO")
evaluate_alignment(pfam_file, gibbs_msa, "Gibbs Refined MSA", "Gibbs")

